use wowd;
DELETE FROM areatriggers;
INSERT INTO areatriggers VALUES(45,1,189,189,'Scarlet Monastery Big East Entrance Istance','1687.569946','1040.089966','20.982901');
INSERT INTO areatriggers VALUES(60,0,24,24,'','47.613499','-28.946199','-8.817590');
INSERT INTO areatriggers VALUES(71,3,0,0,'Westfall - Sentinel Hill Inn','-10645.900391','1179.060059','48.178101');
INSERT INTO areatriggers VALUES(78,0,0,0,'DeadMines Entrance','-11208.669922','1673.168457','24.643379');
INSERT INTO areatriggers VALUES(81,0,28,28,'','-259.246979','137.751175','36.568306');
INSERT INTO areatriggers VALUES(83,0,28,28,'','254.569397','-4.322051','6.486521');
INSERT INTO areatriggers VALUES(84,0,0,0,'','16449.900391','16393.199219','69.444397');
INSERT INTO areatriggers VALUES(87,0,0,0,'Elwinn Forest - Jasperlode mine','-9077.339844','-552.924988','60.347599');
INSERT INTO areatriggers VALUES(88,0,0,0,'Elwinn Forest - Fargodeep mine','-9843.540039','127.525002','5.369800');
INSERT INTO areatriggers VALUES(95,0,30,30,'Alterac Mountains (Coordinate Z Out of Map)','-409.828125','-802.770813','-13.246962');
INSERT INTO areatriggers VALUES(97,0,0,0,'Dun Morogh - Frostmane Hold','-5660.330078','755.299011','389.605011');
INSERT INTO areatriggers VALUES(98,0,0,0,'Stranglethorn Vale - Hunters camp','-11634.799805','-54.069698','13.443900');
INSERT INTO areatriggers VALUES(100,0,0,0,'Tirisfal Glades - Deathknell Night Web Hollow','2019.349365','1904.359375','105.144447');
INSERT INTO areatriggers VALUES(101,1,34,34,'Stormwind Stockades Entrance','54.230000','0.280000','-18.340000');
INSERT INTO areatriggers VALUES(107,0,0,0,'Stormwind Vault Entrance','-8667.559570','623.562988','85.405403');
INSERT INTO areatriggers VALUES(109,0,35,35,'Stormwind Vault Istance','-0.900420','16.443001','-14.236000');
INSERT INTO areatriggers VALUES(119,0,36,36,'DeadMines Istance Start','-12.691923','-382.338104','61.609615');
INSERT INTO areatriggers VALUES(121,0,36,36,'Deadmines Istance End','-110.760002','-1009.190002','34.804401');
INSERT INTO areatriggers VALUES(145,0,0,0,'Shadowfang Keep Entrance','-232.795914','1568.279419','76.890907');
INSERT INTO areatriggers VALUES(168,0,0,0,'Dun Morogh - Frostmane Hold','-5584.206543','759.832153','384.290161');
INSERT INTO areatriggers VALUES(169,0,0,0,'Dun Morogh - Frostmane Hold','-5586.459961','679.297974','384.954987');
INSERT INTO areatriggers VALUES(171,0,0,0,'Loch Modan (Coordinate Z Out of Map)','-5763.720215','-3439.580078','306.365997');
INSERT INTO areatriggers VALUES(173,0,0,0,'','1058.109985','1554.680054','-15.000000');
INSERT INTO areatriggers VALUES(175,0,0,0,'Wetlands - Dun Algaz','-4086.360107','-2610.949951','46.014301');
INSERT INTO areatriggers VALUES(178,0,0,0,'Strahnbrad - Alterac mountains','683.770996','-912.143982','174.500000');
INSERT INTO areatriggers VALUES(194,0,33,33,'Shadowfang keep - Entrance','-230.675446','2106.099854','76.891190');
INSERT INTO areatriggers VALUES(196,0,0,0,'Stranglethorn vale - Vile reef','-12133.724609','938.409241','2.743071');
INSERT INTO areatriggers VALUES(197,0,0,0,'Elwinn Forest - Fargodeep mine','-9796.179688','157.772995','25.387800');
INSERT INTO areatriggers VALUES(205,0,1,1,'','-1895.780029','-1109.040039','86.182999');
INSERT INTO areatriggers VALUES(216,0,1,1,'The Barrens - Forgotten pools','90.100304','-1943.439941','79.472702');
INSERT INTO areatriggers VALUES(217,0,1,1,'Tedrassil - Shadowglen','10708.799805','762.091980','1321.369995');
INSERT INTO areatriggers VALUES(218,0,1,1,'Tedrassil - Star breeze village','9859.089844','588.760986','1300.609985');
INSERT INTO areatriggers VALUES(219,0,1,1,'Tedrassil - Pools of arlithrien','9556.240234','1654.770020','1299.489990');
INSERT INTO areatriggers VALUES(220,0,1,1,'Tedrassil - Oracle glade','10675.200195','1857.449951','1324.170044');
INSERT INTO areatriggers VALUES(223,0,1,1,'Darkshore - Master Glaive','4508.169922','373.376007','32.512501');
INSERT INTO areatriggers VALUES(224,0,1,1,'Darkshore - Master Glaive','4605.569824','385.157990','31.482700');
INSERT INTO areatriggers VALUES(225,0,1,1,'Darkshore - Master Glaive','4558.359863','421.446014','33.742500');
INSERT INTO areatriggers VALUES(226,1,1,1,'The Barrens - Wailing Caverns','-746.207275','-2213.178955','14.890936');
INSERT INTO areatriggers VALUES(228,1,43,43,'The Barrens - Wailing Caverns','-164.995895','135.502792','-73.215523');
INSERT INTO areatriggers VALUES(230,0,1,1,'Darkshore - Bashalaran','6744.979980','41.116402','47.604099');
INSERT INTO areatriggers VALUES(231,0,1,1,'Darkshore','5996.560059','365.209991','21.866100');
INSERT INTO areatriggers VALUES(232,0,1,1,'Darkshore (Coordinate Z Out of Map)','5980.169922','330.669006','21.765499');
INSERT INTO areatriggers VALUES(233,0,1,1,'DarkShore - Twilight vale','4916.990234','328.429993','36.767799');
INSERT INTO areatriggers VALUES(234,0,1,1,'Darkshore - Blackwood den','4641.189941','55.380100','66.630699');
INSERT INTO areatriggers VALUES(235,0,1,1,'DarkShore - Twilight vale','4554.649902','146.354004','59.502701');
INSERT INTO areatriggers VALUES(236,0,1,1,'DarkShore - Twilight vale','4643.379883','145.348999','57.904701');
INSERT INTO areatriggers VALUES(237,0,1,1,'DarkShore - Twilight vale','4504.310059','32.329601','86.491302');
INSERT INTO areatriggers VALUES(238,0,1,1,'DarkShore - Twilight vale','6876.279785','-486.028992','40.143600');
INSERT INTO areatriggers VALUES(239,0,1,1,'Ashenvale - Zoram Strand','3469.429932','847.619995','5.364760');
INSERT INTO areatriggers VALUES(242,1,1,1,'Razorfen Kraul Istance Start','-4464.921387','-1666.239258','90.000000');
INSERT INTO areatriggers VALUES(244,1,47,47,'Razorfen Kraul Entrance','1939.260620','1539.076538','83.279701');
INSERT INTO areatriggers VALUES(246,0,1,1,'Freewind post - Thousand Needles','-4932.529785','-1596.050049','84.815697');
INSERT INTO areatriggers VALUES(254,0,33,33,'Shadowfang Keep Istance (On a castle wall)','-236.470001','2202.419922','97.345200');
INSERT INTO areatriggers VALUES(255,0,33,33,'Shadowfang Keep Istance (On a castle wall)','-223.399002','2101.969971','97.389900');
INSERT INTO areatriggers VALUES(256,0,33,33,'Shadowfang Keep Istance (On a castle wall)','-189.005997','2145.689941','97.389900');
INSERT INTO areatriggers VALUES(257,0,1,1,'Blackphantom Deeps Entrance','4252.370117','756.973999','-23.063200');
INSERT INTO areatriggers VALUES(259,1,1,1,'Blackphantom Deeps Instance Start','4247.738770','745.878601','-24.529881');
INSERT INTO areatriggers VALUES(262,0,47,47,'Razorfen Kraul','2019.729980','2004.599976','61.687401');
INSERT INTO areatriggers VALUES(283,0,48,48,'Blackphantom deeps - The pool of askar','-527.658020','321.109009','-50.258400');
INSERT INTO areatriggers VALUES(284,0,0,0,'StormWind - Old City (Near Stonefist)','-8681.370117','434.406006','99.257896');
INSERT INTO areatriggers VALUES(286,0,0,0,'Uldaman Entrance','-6053.729980','-2954.629883','213.686005');
INSERT INTO areatriggers VALUES(288,0,70,70,'Uldaman Istance Start','-228.192993','34.160198','-39.233898');
INSERT INTO areatriggers VALUES(302,0,1,1,'Dustwallow Marsh - Sentry Point','-3463.260010','-4123.129883','17.104300');
INSERT INTO areatriggers VALUES(303,0,1,1,'Dustwallow Marsh - Den of Flame (Coordinate Z Out of Map)','-4058.750000','-2732.540039','35.330101');
INSERT INTO areatriggers VALUES(322,0,90,90,'Gnomeregan Istance Start','-312.204987','-4.632560','-148.656998');
INSERT INTO areatriggers VALUES(324,0,0,0,'Gnomeregan Entrance','-5161.330078','939.622986','258.287994');
INSERT INTO areatriggers VALUES(342,0,0,0,'Elwinn Forest - Jasperlode mine','-9029.173828','-608.328857','56.467899');
INSERT INTO areatriggers VALUES(362,0,0,0,'The temple of AtalHakkar (Coordinate Z Out of Map)','-10429.434570','-3828.840820','-31.629646');
INSERT INTO areatriggers VALUES(382,0,0,0,'StormWind - Old City (Near Stonefist)','-8681.400391','434.438995','99.259003');
INSERT INTO areatriggers VALUES(422,0,1,1,'Desolace','-93.161400','1691.150024','89.064903');
INSERT INTO areatriggers VALUES(442,1,129,129,'Razorfen Downs Entrance','2593.062012','1109.640015','52.179001');
INSERT INTO areatriggers VALUES(444,0,129,129,'Razorfen Downs Istance Start','2593.939941','1124.640015','56.179001');
INSERT INTO areatriggers VALUES(446,0,0,0,'Altar of AtalHakkar Entrance','-10162.700195','-3998.649902','-107.977997');
INSERT INTO areatriggers VALUES(448,0,109,109,'Altar of AtalHakkar Instance start','-300.000000','99.000000','-127.000000');
INSERT INTO areatriggers VALUES(462,0,47,47,'Razorfen Kraul','2107.719971','1823.770020','79.969597');
INSERT INTO areatriggers VALUES(463,0,47,47,'Razorfen Kraul','2165.750000','1944.750000','61.463501');
INSERT INTO areatriggers VALUES(482,0,0,0,'Razorfen Kraul','-8932.780273','-1986.400024','139.904999');
INSERT INTO areatriggers VALUES(503,1,0,0,'Stockades - Istance','-8764.827148','846.075256','87.484169');
INSERT INTO areatriggers VALUES(522,0,1,1,'Fray Island','-1679.300049','-4328.959961','2.585910');
INSERT INTO areatriggers VALUES(523,1,90,90,'Gnomeregan Train Depot Entrance','-738.209473','2.710169','-250.519577');
INSERT INTO areatriggers VALUES(525,1,0,0,'Gnomeregan Train Fepot Istance','-4858.270020','756.434875','244.922714');
INSERT INTO areatriggers VALUES(527,1,1,1,'Teddrassil - Ruth Theran','8795.801758','969.427429','30.195545');
INSERT INTO areatriggers VALUES(542,1,1,1,'Teddrassil - Darnassus','9946.133789','2627.796631','1318.417236');
INSERT INTO areatriggers VALUES(562,3,0,0,'Elwinn Forest - Goldshire Lions Pride Inn','-9465.580078','16.847200','65.920998');
INSERT INTO areatriggers VALUES(602,1,0,0,'Scarlet Monastery Big West Istance','2924.379883','-798.429016','161.610992');
INSERT INTO areatriggers VALUES(604,1,0,0,'Scarlet Monastery Mini West Instance start','2925.179932','-820.544983','161.634003');
INSERT INTO areatriggers VALUES(606,1,0,0,'Scarlet Monastery Mini East Instance start','2877.984375','-839.267395','163.049179');
INSERT INTO areatriggers VALUES(608,1,0,0,'Scarlet Monastery Big East Instance start','2859.729980','-824.909973','162.082993');
INSERT INTO areatriggers VALUES(610,1,189,189,'Scarlet Monastery Mini West Entrance','853.679016','1308.099976','19.671400');
INSERT INTO areatriggers VALUES(612,1,189,189,'Scarlet Monastery Mini East Entrance','1608.650024','-308.970001','20.782400');
INSERT INTO areatriggers VALUES(614,1,189,189,'Scarlet Monastery Big East Entrance','253.600998','-196.804001','21.038500');
INSERT INTO areatriggers VALUES(682,3,0,0,'Redrige Mountains - Lakeshire inn','-9219.370117','-2149.939941','70.606003');
INSERT INTO areatriggers VALUES(702,1,0,0,'Stormwind - Wizard Sanctum room','-9015.971680','875.317993','148.616898');
INSERT INTO areatriggers VALUES(704,1,0,0,'Stormwind - Wizard Sanctum Tower portal','-9019.160156','887.596313','29.620623');
INSERT INTO areatriggers VALUES(707,3,0,0,'Duskwood - Darkshire Scarlet Raven Inn','-10517.000000','-1158.390015','39.054199');
INSERT INTO areatriggers VALUES(708,3,0,0,'Southshore - Hillsbrad Foothill Inn','-852.854004','-576.711975','20.029301');
INSERT INTO areatriggers VALUES(709,3,1,0,'Theramore isle','-3615.489990','-4467.339844','24.314100');
INSERT INTO areatriggers VALUES(710,3,0,0,'Dun Morogh - Thunderbrew Distillery','-5601.459961','-530.747009','395.483002');
INSERT INTO areatriggers VALUES(712,3,0,0,'Thelsamar - Stoutlager Inn','-5390.180176','-2953.929932','322.029999');
INSERT INTO areatriggers VALUES(713,3,0,0,'Wetlands - Deepwater Tavern','-3823.060059','-834.526001','18.278900');
INSERT INTO areatriggers VALUES(715,3,1,0,'Tedrassil - Donalaar','9809.049805','959.187988','1315.349976');
INSERT INTO areatriggers VALUES(716,3,1,0,'DarkShore - Auberdine','6410.009766','527.034973','14.057800');
INSERT INTO areatriggers VALUES(717,3,1,0,'Ashenvale - Astrannar','2756.639893','-423.057007','119.387001');
INSERT INTO areatriggers VALUES(719,3,0,0,'Tirisfal Glades - Brill Gallows End Tavern','2266.679932','245.992996','44.414501');
INSERT INTO areatriggers VALUES(720,3,0,0,'Sepulcher - Silverpine forest (Coordinate Z Out of Map)','511.536011','1638.630005','120.417297');
INSERT INTO areatriggers VALUES(721,3,0,0,'Tarren Mills - Hillsbrad Footshill','-7.355900','-936.734009','62.333599');
INSERT INTO areatriggers VALUES(722,3,1,0,'Bloodhoff village - Mulgore','-2366.699951','-345.983002','-1.293130');
INSERT INTO areatriggers VALUES(742,3,1,0,'Crossroads - The Barrens','-405.311005','-2645.290039','111.972000');
INSERT INTO areatriggers VALUES(743,3,1,0,'Ratchet - The Barrens','-1051.439941','-3653.810059','31.135201');
INSERT INTO areatriggers VALUES(762,0,48,48,'Blackphantom Deeps istance Akumais lair','-842.075989','-472.462006','-34.065601');
INSERT INTO areatriggers VALUES(802,0,0,0,'Menethil Harbor - WetLands','-3752.810059','-851.557983','10.115300');
INSERT INTO areatriggers VALUES(803,0,0,0,'Menethil Harbor - WetLands','-3668.340088','-823.838989','9.899150');
INSERT INTO areatriggers VALUES(822,0,70,70,'Uldaman Istance Map chamber','-234.444000','319.127014','-47.588501');
INSERT INTO areatriggers VALUES(843,3,1,0,'RazorHill - Durotar','341.420013','-4684.700195','30.949301');
INSERT INTO areatriggers VALUES(844,3,0,0,'Stonard - Swamp of sorrows','-10487.299805','-3256.870117','39.896400');
INSERT INTO areatriggers VALUES(862,3,0,0,'Booty bay - Stranglethorn vale','-14457.000000','496.450012','39.139198');
INSERT INTO areatriggers VALUES(882,0,70,70,'Uldaman Istance End','-213.720001','370.606995','-35.388699');
INSERT INTO areatriggers VALUES(902,0,0,0,'Uldaman Exit','-6606.479980','-3762.189941','266.910004');
INSERT INTO areatriggers VALUES(922,0,209,209,'ZulFarrak Istance start','1190.349976','840.586975','13.434200');
INSERT INTO areatriggers VALUES(924,1,209,209,'ZulFarrak Entrance','1212.349976','842.586975','8.944200');
INSERT INTO areatriggers VALUES(942,0,1,1,'Thousand Needles','-4950.649902','-1625.140015','-3.015700');
INSERT INTO areatriggers VALUES(943,0,1,1,'Thousand Needles','-4950.740234','-1595.140015','-3.015700');
INSERT INTO areatriggers VALUES(944,0,1,1,'Thousand Needles','-4950.649902','-1567.099976','-3.015700');
INSERT INTO areatriggers VALUES(962,0,209,209,'ZulFarrak istance (inside)','1909.270020','1015.109985','11.515500');
INSERT INTO areatriggers VALUES(982,3,1,0,'The Barrens - Camp Taurajo','-2372.510010','-1991.640015','120.974998');
INSERT INTO areatriggers VALUES(1022,0,1,1,'Sun Rock Retrait - Stonetalon','898.481995','922.687988','126.788002');
INSERT INTO areatriggers VALUES(1023,3,1,0,'Gadgetzan - Tanaris','-7164.870117','-3844.469971','13.903000');
INSERT INTO areatriggers VALUES(1024,3,1,0,'Feathermoon Stronghold - Feralas','-4370.830078','3289.149902','23.782301');
INSERT INTO areatriggers VALUES(1025,3,1,0,'Camp Mojache - Feralas','-4458.928711','243.414932','64.613571');
INSERT INTO areatriggers VALUES(1042,0,0,0,'Wildhammer Keep - Hinterlands','357.220001','-2106.090088','121.838997');
INSERT INTO areatriggers VALUES(1064,1,1,1,'Onyxias Lair - Dustwallow istance','-4768.609863','-3752.110107','53.431702');
INSERT INTO areatriggers VALUES(1103,0,0,0,'Booty Bay - Stranglethorn','-14468.000000','457.513000','15.982200');
INSERT INTO areatriggers VALUES(1104,0,0,0,'Gnomeregan - Dun Morogh entrance','-5096.759766','750.205017','260.549988');
INSERT INTO areatriggers VALUES(1105,0,90,90,'Gnomeregan - Dun Morogh istance','-377.056000','44.049999','-156.483002');
INSERT INTO areatriggers VALUES(1125,0,0,0,'Cathedral of Light - Stormwind','-8561.540039','823.382996','106.518997');
INSERT INTO areatriggers VALUES(1205,0,0,0,'Altar of Zul - Hinterlands','-295.639008','-3460.679932','193.884003');
INSERT INTO areatriggers VALUES(1306,0,109,109,'The temple of AtalHakkar - Ungoro Crater istance','-496.854004','42.692902','-91.131798');
INSERT INTO areatriggers VALUES(1326,0,109,109,'The temple of AtalHakkar - Ungoro Crater istance','-467.520996','95.308296','-105.000000');
INSERT INTO areatriggers VALUES(1387,0,1,1,'The Shattered Strand - Azshara','4260.729980','-6273.640137','90.228897');
INSERT INTO areatriggers VALUES(1388,0,1,1,'Talassian Base Camp - Azshara','4277.580078','-6296.000000','95.576401');
INSERT INTO areatriggers VALUES(1426,0,0,0,'Blasted Lands','-11204.500000','-2730.610107','14.897200');
INSERT INTO areatriggers VALUES(1427,0,0,0,'Rise of Defiler - Blasted Lands','-11079.700195','-2855.639893','10.691100');
INSERT INTO areatriggers VALUES(1428,0,0,0,'Rise of Defiler - Blasted Lands','-11208.099609','-2960.479980','9.214490');
INSERT INTO areatriggers VALUES(1429,0,0,0,'Rise of Defiler - Blasted Lands','-11337.400391','-2848.929932','9.344040');
INSERT INTO areatriggers VALUES(1446,0,0,0,'Rise of Defiler - Blasted Lands','-11185.099609','-2834.629883','116.473999');
INSERT INTO areatriggers VALUES(1447,0,209,209,'Zul Farrak - Tanaris istance (inside)','1811.050049','700.976013','15.294000');
INSERT INTO areatriggers VALUES(1466,1,230,230,'Blackrock Mountain - Searing Gorge istance?','457.968994','35.368000','-69.245300');
INSERT INTO areatriggers VALUES(1468,1,229,229,'Blackrock Spire - Searing Gorge istance (inside)','78.508301','-225.044006','49.839020');
INSERT INTO areatriggers VALUES(1470,0,229,229,'Blackrock Spire - Searing Gorge istance','73.508301','-215.044006','52.386902');
INSERT INTO areatriggers VALUES(1472,0,230,230,'Blackrock Dephts - Searing Gorge istance','456.968994','48.368000','-65.275299');
INSERT INTO areatriggers VALUES(1506,0,0,0,'Dredmaul Rock - Burning Steppes','-7921.140137','-2604.179932','223.345993');
INSERT INTO areatriggers VALUES(1526,0,230,230,'Blackrock Dephts - Searing Gorge istance','596.432007','-188.498001','-50.000000');
INSERT INTO areatriggers VALUES(1590,0,230,230,'Blackrock Dephts - Searing Gorge istance','376.105988','-191.242004','-70.544899');
INSERT INTO areatriggers VALUES(1606,0,0,0,'Kargath - Badlands','-6657.350098','-2157.100098','264.132996');
INSERT INTO areatriggers VALUES(1626,0,269,269,'Old Hillsbrad Foothills - istance ?','3122.199951','2324.639893','-129.320007');
INSERT INTO areatriggers VALUES(1628,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','-78.581902','-401.394989','38.942799');
INSERT INTO areatriggers VALUES(1629,0,269,269,'The Black Morass - istance (inside)','-2061.120117','6635.970215','-144.595993');
INSERT INTO areatriggers VALUES(1631,0,1,1,'Cavern of Times - Tanaris istance (inside)','-8280.790039','-4025.139893','-181.059006');
INSERT INTO areatriggers VALUES(1632,0,1,1,'Cavern of Times - Tanaris istance (inside)','-8799.190430','-4115.160156','-199.998993');
INSERT INTO areatriggers VALUES(1646,0,0,0,'Hammerfall - Arathi Highlands','-907.864990','-3534.239990','83.787804');
INSERT INTO areatriggers VALUES(1667,0,1,1,'Sentry Point - Dustwallow Marsh','-3464.709961','-4120.930176','17.098700');
INSERT INTO areatriggers VALUES(1686,0,230,230,'Blackrock Dephts - Searing Gorge istance (inside)','319.973999','-215.184998','-77.954201');
INSERT INTO areatriggers VALUES(1726,0,1,1,'The Marshlands - Ungoro Crater','-7286.009766','-2125.060059','-272.114014');
INSERT INTO areatriggers VALUES(1727,0,1,1,'The Marshlands - Ungoro Crater','-7208.419922','-2027.089966','-271.739990');
INSERT INTO areatriggers VALUES(1728,0,1,1,'The Marshlands - Ungoro Crater','-7170.020020','-1852.790039','-272.988007');
INSERT INTO areatriggers VALUES(1729,0,1,1,'The Marshlands - Ungoro Crater','-7395.189941','-1735.680054','-279.763000');
INSERT INTO areatriggers VALUES(1730,0,1,1,'The Marshlands - Ungoro Crater','-7449.899902','-2111.570068','-271.765991');
INSERT INTO areatriggers VALUES(1731,0,1,1,'The Marshlands - Ungoro Crater','-7463.350098','-1957.640015','-272.532013');
INSERT INTO areatriggers VALUES(1732,0,1,1,'The Marshlands - Ungoro Crater','-7509.580078','-1946.560059','-270.536987');
INSERT INTO areatriggers VALUES(1733,0,1,1,'The Marshlands - Ungoro Crater','-7516.870117','-1829.760010','-272.647003');
INSERT INTO areatriggers VALUES(1734,0,1,1,'The Marshlands - Ungoro Crater','-7594.120117','-1771.619995','-273.612000');
INSERT INTO areatriggers VALUES(1735,0,1,1,'The Marshlands - Ungoro Crater','-7748.899902','-1721.140015','-271.908997');
INSERT INTO areatriggers VALUES(1736,0,1,1,'The Marshlands - Ungoro Crater','-7768.609863','-1957.630005','-272.126007');
INSERT INTO areatriggers VALUES(1737,0,1,1,'The Marshlands - Ungoro Crater','-7612.560059','-1930.869995','-271.828003');
INSERT INTO areatriggers VALUES(1738,0,1,1,'The Marshlands - Ungoro Crater','-7952.200195','-1792.010010','-272.893005');
INSERT INTO areatriggers VALUES(1739,0,1,1,'Ungoro Crater','-7895.290039','-1623.619995','-269.707001');
INSERT INTO areatriggers VALUES(1740,0,1,1,'The Marshlands - Ungoro Crater','-7874.180176','-1806.300049','-271.459015');
INSERT INTO areatriggers VALUES(1741,0,1,1,'Ungoro Crater -The Northern Pylon','-6219.615723','-1551.455688','-221.241150');
INSERT INTO areatriggers VALUES(1746,0,230,230,'Blackrock Dephts - Searing Gorge istance (inside)','411.617004','-201.645996','-65.144600');
INSERT INTO areatriggers VALUES(1766,0,1,1,'The Marshlands - Ungoro Crater','-7308.713379','-2001.473145','-272.450500');
INSERT INTO areatriggers VALUES(1786,0,230,230,'Blackrock Dephts - Searing Gorge istance (inside)','690.518005','-280.052002','-43.196899');
INSERT INTO areatriggers VALUES(1826,0,230,230,'Blackrock Dephts - Searing Gorge istance (inside)','471.141998','-9.343780','-69.799301');
INSERT INTO areatriggers VALUES(1827,0,230,230,'Blackrock Dephts - Searing Gorge istance (inside)','1380.150024','-554.604004','-89.642998');
INSERT INTO areatriggers VALUES(1828,0,230,230,'Blackrock Dephts - Searing Gorge istance (inside)','497.398987','13.231900','-70.137199');
INSERT INTO areatriggers VALUES(1906,0,1,1,'Darkshore','6818.560059','-391.734985','40.123001');
INSERT INTO areatriggers VALUES(1926,0,230,230,'Blackrock Dephts - Searing Gorge istance (inside)','845.911011','-317.368988','-50.286800');
INSERT INTO areatriggers VALUES(1946,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','70.861099','-409.014008','64.347702');
INSERT INTO areatriggers VALUES(1966,0,1,1,'Twilight Shore - Darkshore','4988.970215','547.002014','5.379290');
INSERT INTO areatriggers VALUES(1986,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','91.085403','-408.373993','64.347702');
INSERT INTO areatriggers VALUES(1987,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','109.608002','-415.697998','64.347702');
INSERT INTO areatriggers VALUES(2026,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','153.763000','-419.833008','110.472000');
INSERT INTO areatriggers VALUES(2046,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','102.430000','-319.166992','65.463501');
INSERT INTO areatriggers VALUES(2066,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','75.262199','-547.679016','110.928001');
INSERT INTO areatriggers VALUES(2067,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','26.458300','-522.471008','110.943001');
INSERT INTO areatriggers VALUES(2068,0,229,229,'Hall of Blackhand - Searing Gorge istance (inside)','25.928499','-299.325012','24.109501');
INSERT INTO areatriggers VALUES(2146,0,0,0,'','16299.200195','16277.299805','73.972298');
INSERT INTO areatriggers VALUES(2166,1,0,0,'Deeprun Tram - Ironforge istance (inside)','-4838.954102','-1318.460205','501.867920');
INSERT INTO areatriggers VALUES(2171,1,0,0,'Deeprun Tram - Stormwind istance (inside)','-8364.570313','535.980896','91.796860');
INSERT INTO areatriggers VALUES(2173,1,369,369,'Deeprun Tram - Stormwind istance','68.300598','2490.910156','-4.296469');
INSERT INTO areatriggers VALUES(2175,1,369,369,'Deeprun Tram - Ironforge istance','69.254242','10.256980','-4.296640');
INSERT INTO areatriggers VALUES(2187,0,329,329,'Stratholme - Eastern Plaguelands istance (inside)','3673.600098','-3633.870117','139.942993');
INSERT INTO areatriggers VALUES(2206,0,1,1,'Shatter Scar Vale - Felwood','5483.899902','-749.880981','334.621002');
INSERT INTO areatriggers VALUES(2207,0,1,1,'Shatter Scar Vale - Felwood','5552.089844','-683.812988','335.250000');
INSERT INTO areatriggers VALUES(2208,0,1,1,'Shatter Scar Vale - Felwood','5587.020020','-784.025024','335.821991');
INSERT INTO areatriggers VALUES(2209,0,329,329,'Stratholme - Eastern Plaguelands istance (inside)','3665.110107','-3164.959961','127.223999');
INSERT INTO areatriggers VALUES(2210,0,329,329,'Stratholme - Eastern Plaguelands istance (inside)','3663.949951','-3164.270020','127.361000');
INSERT INTO areatriggers VALUES(2211,0,1,1,'Mazthoril - Winterspring','6107.620117','-4181.600098','852.322021');
INSERT INTO areatriggers VALUES(2213,0,1,1,'Mazthoril - Winterspring','5893.319824','-4054.830078','596.322021');
INSERT INTO areatriggers VALUES(2214,1,329,329,'Stratholme - Eastern Plaguelands istance','3590.780029','-3640.050049','139.117996');
INSERT INTO areatriggers VALUES(2216,1,329,329,'Stratholme - Eastern Plaguelands istance','3395.090088','-3380.250000','142.701996');
INSERT INTO areatriggers VALUES(2217,1,329,329,'Stratholme - Eastern Plaguelands istance','3395.090088','-3380.250000','142.701996');
INSERT INTO areatriggers VALUES(2221,1,0,0,'Stratholme - Eastern Plaguelands istance (inside)','3235.459961','-4050.600098','110.010002');
INSERT INTO areatriggers VALUES(2226,1,1,1,'Ragefire Chasm - Ogrimmar istance (inside)','1818.400024','-4427.259766','-10.447800');
INSERT INTO areatriggers VALUES(2230,1,389,389,'Ragefire Chasm - Ogrimmar istance','2.580190','-0.013587','-13.366800');
INSERT INTO areatriggers VALUES(2246,1,0,0,'Felstone Field - Western Plaguelands','1855.130005','-1569.219971','59.182499');
INSERT INTO areatriggers VALUES(2248,1,0,0,'Dalsons Tears - Western Plaguelands','1757.260010','-1165.930054','59.602501');
INSERT INTO areatriggers VALUES(2250,1,0,0,'The Writhing Haunt - Western Plaguelands','1668.119995','-2282.560059','59.222099');
INSERT INTO areatriggers VALUES(2252,1,0,0,'Gahrorons Withering - Western Plaguelands','1462.130005','-1864.020020','58.702801');
INSERT INTO areatriggers VALUES(2266,3,1,0,'Nijels Point - Desolace','245.587006','1251.989990','210.145004');
INSERT INTO areatriggers VALUES(2267,3,1,0,'Shadowprey Village - Desolace','-1596.160034','3145.260010','67.833801');
INSERT INTO areatriggers VALUES(2286,3,1,0,'Freewind Post - Thousand Needles','-5474.600098','-2459.310059','103.730003');
INSERT INTO areatriggers VALUES(2287,3,1,0,'Everlook - Winterspring','6687.990234','-4670.069824','723.890991');
INSERT INTO areatriggers VALUES(2327,0,1,1,'Darkwhisper Gorge - Winterspring','5018.910156','-4563.939941','851.750000');
INSERT INTO areatriggers VALUES(2387,0,0,0,'Swamp of Sorrow','-9897.209961','-3725.090088','24.667101');
INSERT INTO areatriggers VALUES(2406,0,33,33,'Shadowfang Keep - Silverpine istance','-287.071014','2175.639893','36.886101');
INSERT INTO areatriggers VALUES(2407,0,33,33,'Shadowfang Keep - Silverpine istance','-315.990997','2179.629883','91.754204');
INSERT INTO areatriggers VALUES(2408,0,33,33,'Shadowfang Keep - Silverpine istance','-232.371994','2077.100098','68.117699');
INSERT INTO areatriggers VALUES(2409,0,33,33,'Shadowfang Keep - Silverpine istance','-255.272995','2035.760010','114.436996');
INSERT INTO areatriggers VALUES(2410,0,33,33,'Shadowfang Keep - Silverpine istance','-167.091995','2104.219971','73.449699');
INSERT INTO areatriggers VALUES(2411,0,33,33,'','-179.729004','2079.370117','42.694500');
INSERT INTO areatriggers VALUES(2412,0,0,0,'Alterac Valley - Alterac istance PVP','97.431999','-176.274002','127.865997');
INSERT INTO areatriggers VALUES(2413,1,30,30,'Alterac Valley - Alterac istance PVP','943.833008','-503.092010','94.689499');
INSERT INTO areatriggers VALUES(2416,0,451,451,'Programmer Island','16304.200195','16318.099609','69.444397');
INSERT INTO areatriggers VALUES(2426,0,469,469,'Blackwing Lair - ?','-7474.009766','-1286.339966','431.303986');
INSERT INTO areatriggers VALUES(2427,0,469,469,'Blackwing Lair - ?','-7375.319824','-1240.140015','494.279999');
INSERT INTO areatriggers VALUES(2428,0,469,469,'Blackwing Lair - ?','-7568.399902','-1375.660034','468.507996');
INSERT INTO areatriggers VALUES(2429,0,469,469,'Blackwing Lair - ?','-7412.970215','-1371.589966','413.425995');
INSERT INTO areatriggers VALUES(2486,0,1,1,'Darkshore','6207.500000','-152.832993','79.818497');
INSERT INTO areatriggers VALUES(2527,1,450,450,'Hall of the Brave - Ogrimmar','215.194000','71.156998','30.127600');
INSERT INTO areatriggers VALUES(2530,1,1,1,'Hall of the Brave - Ogrimmar (inside)','1643.359985','-4233.600098','56.155701');
INSERT INTO areatriggers VALUES(2532,1,449,449,'Stormwind - near Old Town','-0.199573','-1.591120','-0.255884');
INSERT INTO areatriggers VALUES(2534,1,0,0,'Stormwind (inside) - near Old Town','-8768.080078','409.204987','103.920998');
INSERT INTO areatriggers VALUES(2547,0,289,289,'Scholomance - Western Plaguelands istance','332.865997','94.310799','92.222099');
INSERT INTO areatriggers VALUES(2548,0,289,289,'Scholomance - Western Plaguelands istance','322.884003','112.137001','98.672600');
INSERT INTO areatriggers VALUES(2549,0,289,289,'scholomance exit','325.183990','75.618103','93.874397');
INSERT INTO areatriggers VALUES(2567,1,289,289,'scholomance entrance','189.606995','126.649994','138.707001');
INSERT INTO areatriggers VALUES(2568,1,0,0,'Scholomance istance','1275.050049','-2552.030029','90.399399');
INSERT INTO areatriggers VALUES(2606,1,0,0,'alterac valley entrance','98.431999','-182.274002','127.519974');
INSERT INTO areatriggers VALUES(2608,1,0,0,'alterac valley istance','539.830017','-1084.949951','106.444000');
INSERT INTO areatriggers VALUES(2610,0,1,1,'','2343.570068','-2569.000000','118.827003');
INSERT INTO areatriggers VALUES(2626,0,0,0,'western plaguelands - felstone field','1756.790039','-1200.150024','60.735199');
INSERT INTO areatriggers VALUES(2627,0,0,0,'western plaguelands - felstone field','1723.319946','-1198.380005','60.009602');
INSERT INTO areatriggers VALUES(2628,0,0,0,'western plaguelands - felstone field','1723.099976','-1166.709961','59.577499');
INSERT INTO areatriggers VALUES(2629,0,0,0,'western plaguelands - dalsons tears','1879.598511','-1546.082642','59.030109');
INSERT INTO areatriggers VALUES(2630,0,0,0,'western plaguelands - dalsons tears','1903.000000','-1570.260010','59.703499');
INSERT INTO areatriggers VALUES(2631,0,0,0,'western plaguelands - dalsons tears','1878.079956','-1593.739990','59.473900');
INSERT INTO areatriggers VALUES(2632,0,0,0,'western plaguelands - the writhing haunt','1487.030029','-1840.910034','58.667500');
INSERT INTO areatriggers VALUES(2633,0,0,0,'','1510.459961','-1863.239990','59.105999');
INSERT INTO areatriggers VALUES(2634,0,0,0,'','1485.609985','-1888.689941','59.090199');
INSERT INTO areatriggers VALUES(2635,0,0,0,'western plaguelands - gahrrons withering','1681.116821','-2250.931885','59.021118');
INSERT INTO areatriggers VALUES(2636,0,0,0,'western plaguelands - gahrrons withering','1712.750000','-2263.280029','64.088898');
INSERT INTO areatriggers VALUES(2637,0,0,0,'western plaguelands - gahrrons withering','1700.250000','-2295.360107','58.984600');
INSERT INTO areatriggers VALUES(2647,0,0,0,'western plagueands - felstone field','2841.810059','-1544.520020','188.516006');
INSERT INTO areatriggers VALUES(2706,0,0,0,'eastern plaguelands - terror web tunnel','2964.560059','-2712.889893','98.744598');
INSERT INTO areatriggers VALUES(2707,0,0,0,'eastern plaguelands - terror web tunnel','2980.100098','-2720.919922','99.933701');
INSERT INTO areatriggers VALUES(2726,0,0,0,'eastern plaguelands - marris stead','1868.959961','-3223.389893','123.065002');
INSERT INTO areatriggers VALUES(2746,0,0,0,'trade district - sw city','-8821.360352','633.296997','94.075798');
INSERT INTO areatriggers VALUES(2766,0,469,469,'dragonmaw garrison - blackwing lair','-7621.589844','-1071.479980','408.489990');
INSERT INTO areatriggers VALUES(2767,0,469,469,'Blackwing Lair - ?','-7621.729980','-1070.609985','408.489990');
INSERT INTO areatriggers VALUES(2786,3,0,0,'Stormwind City - Gates','-9050.870117','445.458008','93.055801');
INSERT INTO areatriggers VALUES(2848,1,249,249,'Onyxias Lair Entrance','29.242701','-22.181200','10.527200');
INSERT INTO areatriggers VALUES(2886,1,409,409,'The Molten Bridge','1098.989990','-469.493988','-104.958992');
INSERT INTO areatriggers VALUES(2890,1,230,230,'The Molten Core','1115.219971','-460.959015','-103.494804');
INSERT INTO areatriggers VALUES(2926,0,1,1,'Mystral Lake - Ashenvale','1999.150024','-1121.280029','97.353699');
INSERT INTO areatriggers VALUES(2946,0,1,1,'Boulderside Ravine - Stonetalon mountains','-122.390999','388.013000','94.485603');
INSERT INTO areatriggers VALUES(3066,0,0,0,'','18.944799','-1448.219971','176.149994');
INSERT INTO areatriggers VALUES(3106,0,0,0,'','-30.053301','-1576.500000','194.453003');
INSERT INTO areatriggers VALUES(3126,0,349,349,'Maraudon','756.877991','-633.960022','-32.819099');
INSERT INTO areatriggers VALUES(3131,0,349,349,'Maraudon','1005.020020','-460.539001','-43.250702');
INSERT INTO areatriggers VALUES(3133,1,349,349,'Maraudon','1012.020020','-459.539001','-43.507019');
INSERT INTO areatriggers VALUES(3134,1,349,349,'Maraudon','755.877991','-620.960022','-33.051910');
INSERT INTO areatriggers VALUES(3146,0,1,1,'','-7180.939941','441.136993','26.544901');
INSERT INTO areatriggers VALUES(3182,0,1,1,'Dire Maul','-3577.669922','841.859009','134.593994');
INSERT INTO areatriggers VALUES(3183,1,429,429,'Dire Maul','44.449902','-154.822006','-2.712010');
INSERT INTO areatriggers VALUES(3184,0,1,1,'Dire Maul','-3981.580078','771.192993','160.962006');
INSERT INTO areatriggers VALUES(3185,1,429,429,'Dire Maul','9.311190','-837.085022','-32.530502');
INSERT INTO areatriggers VALUES(3186,0,1,1,'Dire Maul','-3837.790039','1250.229980','160.223007');
INSERT INTO areatriggers VALUES(3187,1,429,429,'Dire Maul','31.560900','159.449997','-3.477700');
INSERT INTO areatriggers VALUES(3188,0,1,1,'Dire Maul - door no exit','-3519.189941','1176.709961','161.128006');
INSERT INTO areatriggers VALUES(3189,1,429,429,'Dire Maul','255.248993','-16.056061','-2.587370');
INSERT INTO areatriggers VALUES(3190,0,429,429,'Dire Maul','-55.965801','159.867004','-3.462060');
INSERT INTO areatriggers VALUES(3191,0,429,429,'Dire Maul','24.560900','159.449997','-3.466770');
INSERT INTO areatriggers VALUES(3192,0,429,429,'Dire Maul - door no exit','255.341003','78.964302','-2.593290');
INSERT INTO areatriggers VALUES(3193,0,429,429,'Dire Maul','255.248993','-9.056060','-2.587370');
INSERT INTO areatriggers VALUES(3194,0,429,429,'Dire Maul','37.449902','-154.822006','-2.712010');
INSERT INTO areatriggers VALUES(3195,0,429,429,'Dire Maul','-202.664001','-314.876007','-2.723530');
INSERT INTO areatriggers VALUES(3196,0,429,429,'Dire Maul','4.311190','-837.085022','-33.040501');
INSERT INTO areatriggers VALUES(3197,0,429,429,'Dire Maul','194.350998','-240.820999','-25.630699');
INSERT INTO areatriggers VALUES(3306,0,469,469,'Blackwing Lair - ?','-7523.990234','-1013.080017','408.570007');
INSERT INTO areatriggers VALUES(3326,0,30,30,'alterac valley','-758.822021','-348.119995','90.979698');
INSERT INTO areatriggers VALUES(3327,0,30,30,'alterac valley','-1221.349976','-352.877014','57.721199');
INSERT INTO areatriggers VALUES(3328,0,30,30,'alterac valley','-1300.420044','-266.231995','114.278999');
INSERT INTO areatriggers VALUES(3329,0,30,30,'alterac valley','213.666000','-373.242004','56.391399');
INSERT INTO areatriggers VALUES(3330,0,30,30,'alterac valley','326.519012','-503.868988','71.144798');
INSERT INTO areatriggers VALUES(3331,0,30,30,'alterac valley','683.036987','-129.654999','63.666302');
INSERT INTO areatriggers VALUES(3366,0,0,0,'','2832.070068','-1540.479980','190.164993');
INSERT INTO areatriggers VALUES(3367,0,0,0,'','2843.399902','-1553.260010','190.720993');
INSERT INTO areatriggers VALUES(3506,0,429,429,'Dire Maul','580.754028','487.506012','29.464100');
INSERT INTO areatriggers VALUES(3507,0,429,429,'Dire Maul','580.656982','475.885010','29.464100');
INSERT INTO areatriggers VALUES(3508,0,429,429,'Dire Maul','592.507019','486.309998','29.464100');
INSERT INTO areatriggers VALUES(3509,0,429,429,'Dire Maul','591.919983','476.403992','29.464100');
INSERT INTO areatriggers VALUES(3528,0,0,0,'','-7513.220215','-1033.770020','181.834000');
INSERT INTO areatriggers VALUES(3529,0,0,0,'','-7512.160156','-1034.780029','177.207993');
INSERT INTO areatriggers VALUES(3530,0,0,0,'','-8536.179688','452.165009','104.917000');
INSERT INTO areatriggers VALUES(3546,3,1,0,'','9933.940430','2500.979980','1317.819946');
INSERT INTO areatriggers VALUES(3547,0,0,0,'','1642.099976','239.843002','62.591999');
INSERT INTO areatriggers VALUES(3548,0,0,0,'','-4754.560059','-3313.800049','313.563995');
INSERT INTO areatriggers VALUES(3549,0,1,1,'','1253.790039','-2227.520020','92.248001');
INSERT INTO areatriggers VALUES(3550,0,1,1,'','-959.299011','-3759.209961','4.986000');
INSERT INTO areatriggers VALUES(3551,0,1,1,'','-998.182983','-3822.070068','5.295000');
INSERT INTO areatriggers VALUES(3552,0,0,0,'','-11413.599609','1954.910034','14.241000');
INSERT INTO areatriggers VALUES(3586,0,1,1,'','6221.839844','-1152.750000','383.230988');
INSERT INTO areatriggers VALUES(3587,0,1,1,'','6221.890137','-1153.000000','383.272003');
INSERT INTO areatriggers VALUES(3606,0,0,0,'','-7514.810059','-1033.119995','163.806000');
INSERT INTO areatriggers VALUES(3626,0,469,469,'Blackwing Lair - ?','-7529.100098','-1007.190002','408.565002');
INSERT INTO areatriggers VALUES(3646,0,489,489,'Warsong Gulch - Alliance Flag spawn','1538.040039','1481.459961','352.408997');
INSERT INTO areatriggers VALUES(3647,0,489,489,'Warsong Gulch - Horde Flag spawn','918.049011','1434.099976','346.476013');
INSERT INTO areatriggers VALUES(3649,0,489,489,'Warsong Gulch - Horde Flag spawn','918.049011','1434.099976','346.476013');
INSERT INTO areatriggers VALUES(3650,1,489,489,'Ashenvale - Silverwing Grove (Warsong Gulch - Alliance Entrance)','1524.050049','1481.119995','352.000000');
INSERT INTO areatriggers VALUES(3654,1,489,489,'Barrens - Mor`shan Base camp (Warsong Gulch - Horde Entrance)','930.219971','1435.130005','345.500000');
INSERT INTO areatriggers VALUES(3669,0,489,489,'Warsong Gulch - Horde Exit','1009.166992','1290.766968','346.960999');
INSERT INTO areatriggers VALUES(3671,0,489,489,'Warsong Gulch - Alliance Exit','1456.468018','1628.468018','360.351990');
INSERT INTO areatriggers VALUES(3686,0,489,489,'Warsong Gulch - Alliance elexir of speed spawn','1449.766968','1470.567017','342.625000');
INSERT INTO areatriggers VALUES(3687,0,489,489,'Warsong Gulch - Horde elexir of speed spawn','1005.267029','1447.266968','335.893005');
INSERT INTO areatriggers VALUES(3688,0,489,489,'Warsong Gulch - Horde side','1125.227051','1541.500977','307.391998');
INSERT INTO areatriggers VALUES(3690,0,0,0,'','-622.142029','-4582.140137','22.576000');
INSERT INTO areatriggers VALUES(3706,0,489,489,'Warsong Gulch - Alliance elexir of regeneration spawn','1316.967041','1550.968018','313.234009');
INSERT INTO areatriggers VALUES(3707,0,489,489,'Warsong Gulch - Alliance elexir of berserk spawn','1319.766968','1378.666992','314.752991');
INSERT INTO areatriggers VALUES(3708,0,489,489,'Warsong Gulch - Horde elexir of regeneration spawn','1107.866943','1354.266968','316.431000');
INSERT INTO areatriggers VALUES(3709,0,489,489,'Warsong Gulch - Horde elexir of berserk spawn','1140.067017','1560.766968','306.824005');
INSERT INTO areatriggers VALUES(3726,0,229,229,'Blackwing Lair - Blackrock Mountain - Eastern Kingdoms','171.117767','-474.738098','116.842400');
INSERT INTO areatriggers VALUES(3728,1,229,229,'Blackwing Lair - Blackrock Mountain - Eastern Kingdoms','171.117767','-474.738098','116.842400');
INSERT INTO areatriggers VALUES(3746,0,36,36,'Deadmines Instance (near entrance)','-29.555000','-374.502991','59.355999');
INSERT INTO areatriggers VALUES(3766,0,43,43,'Wailing Caverns Instance (near entrance)','-108.563004','160.914993','-79.791000');
INSERT INTO areatriggers VALUES(3806,0,529,529,'Arathi Basin - NEW PVP BG','1182.280029','1183.180054','-45.255001');
INSERT INTO areatriggers VALUES(3807,0,529,529,'Arathi Basin','1181.619995','1183.390015','-45.328999');
INSERT INTO areatriggers VALUES(3808,0,529,529,'Arathi Basin','997.143982','1001.159973','-31.437000');
INSERT INTO areatriggers VALUES(3809,0,529,529,'Arathi Basin','997.091980','1001.469971','-31.336000');
INSERT INTO areatriggers VALUES(3810,0,529,529,'Arathi Basin','819.994995','813.552002','-57.646000');
INSERT INTO areatriggers VALUES(3811,0,529,529,'Arathi Basin','820.005981','813.830994','-57.667000');
INSERT INTO areatriggers VALUES(3812,0,529,529,'Arathi Basin','819.327026','1178.430054','36.384998');
INSERT INTO areatriggers VALUES(3813,0,529,529,'Arathi Basin','819.390015','1178.500000','36.384998');
INSERT INTO areatriggers VALUES(3814,0,529,529,'Arathi Basin','1174.000000','830.033020','-106.573997');
INSERT INTO areatriggers VALUES(3815,0,529,529,'Arathi Basin','1174.140015','830.088989','-106.553001');
INSERT INTO areatriggers VALUES(3846,0,0,0,'Blackrock Mountain - Orb of Command - spawn','-7663.580078','-1218.359985','287.787994');
INSERT INTO areatriggers VALUES(3926,0,309,309,'','-11594.099609','-1621.369995','47.145000');
INSERT INTO areatriggers VALUES(3928,1,309,309,'','-11917.000000','-1230.000000','97.561996');
INSERT INTO areatriggers VALUES(3930,0,309,309,'','-11917.000000','-1230.000000','97.561996');
INSERT INTO areatriggers VALUES(3956,0,309,309,'','-11918.599609','-1433.949951','44.544998');
INSERT INTO areatriggers VALUES(3957,0,309,309,'','-11916.799805','-1256.699951','92.542999');
INSERT INTO areatriggers VALUES(3958,0,309,309,'','-11915.043945','-1312.676025','77.501999');
INSERT INTO areatriggers VALUES(3959,0,309,309,'','-11945.688477','-1597.607056','36.757000');
INSERT INTO areatriggers VALUES(3960,0,309,309,'','-11788.900391','-1595.060059','36.999001');
INSERT INTO areatriggers VALUES(3961,0,309,309,'','-11614.200195','-1361.510010','76.839996');
INSERT INTO areatriggers VALUES(3962,0,309,309,'','-11957.599609','-1819.969971','54.311001');
INSERT INTO areatriggers VALUES(3963,0,309,309,'','-12112.900391','-1794.630005','80.416000');
INSERT INTO areatriggers VALUES(3964,0,309,309,'','-11791.000000','-1562.859985','19.742001');
INSERT INTO areatriggers VALUES(3965,0,309,309,'','-11610.000000','-1749.859985','38.734001');
INSERT INTO areatriggers VALUES(3966,0,309,309,'','-12072.299805','-1479.050049','106.495003');
INSERT INTO areatriggers VALUES(33009,3,0,0,'Dinner Hall - Shadowfang Keep - Silverpine Forest - Azeroth','0.000000','0.000000','0.000000');
INSERT INTO areatriggers VALUES(700032,3,0,0,'Darkcloud Pinnacle Kalimdor','0.000000','0.000000','0.000000');
INSERT INTO areatriggers VALUES(700129,3,0,0,'Shady Rest Inn Kalimdor','0.000000','0.000000','0.000000');
