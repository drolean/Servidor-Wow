**Oficial WowD Database***
**Version: 1.0
**Revision: 6

This database contains all work from wowd team with creatures, objects and other features to make the world content more near the oficial one.
Any new features like making npcs to talk etc etc will be added here.

All world content will be updated on each revision by me(you know who).

Use this database to test features and to add new ones.

Npcs need to be reworked like adding quests gossips, trainers, vendors etc that can fill them with content :)


Corrent Content:
FUll kalimdor and Estern Kingdoms spawned.
World raid bosses





Statistics:
-------------------------
Creatures: 47935
Creature Names: 4715
Game Objects: 14750
Game Objects Names: 5605
Instance Creatures: 0
Instance Game Objects: 0
Quests:
Trainers:
Gossips:
Gossips Texts:



Warning: DO NOT ADD BUGGED FEATURES TO IT OR RANDOM STUFF THAT IS WRONG.
	 WE WANT A WORKING DATABASE AND NOT BUGGED AT ALL. THX
