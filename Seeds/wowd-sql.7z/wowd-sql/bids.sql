CREATE TABLE `bids` (
  `bidder` int(32) NOT NULL default '0',
  `ID` int(32) NOT NULL default '0',
  `amt` int(32) NOT NULL default '0'  
) TYPE=MyISAM;
