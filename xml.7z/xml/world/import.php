#!/usr/bin/env php
<?php
$conn = new mysqli('127.0.0.1', 'homestead', 'secret', 'mangos');
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}
/*
0       Eastern Kingdoms
1       Kalimdor
*2       Under Mine
*13      Testing
*25      Scott Test
*29      CashTest
30      Alterac Valley
33      Shadowfang Keep
34      Stormwind Stockade
*35      StormwindPrison
36      Deadmines
*37      Azshara Crater
*42      Collin's Test
43      Wailing Caverns
*44      Monastery
47      Razorfen Kraul
48      Blackfathom Deeps
70      Uldaman
90      Gnomeregan
109     Sunken Temple
129     Razorfen Downs
169     Emerald Dream
189     Scarlet Monastery
209     Zul'Farrak
229     Blackrock Spire
230     Blackrock Depths
249     Onyxia's Lair
269     Black Morass
289     Scholomance
309     Zul'Gurub
329     Stratholme
349     Maraudon
369     Deeprun Tram
389     Ragefire Chasm
409     Molten Core
429     Dire Maul
449     Champions' Hall
450     Hall of Legends
451     Development Land
469     Blackwing Lair
489     Warsong Gulch
509     Ruins of Ahn'Qiraj
529     Arathi Basin
531     Temple of Ahn'Qiraj
533     Naxxramas
*/
$sql = "
SELECT
    gameobject.id,
    gameobject.map,
    gameobject.position_x,
    gameobject.position_y,
    gameobject.position_z,
    gameobject.orientation,
    gameobject.spawnFlags,
    gameobject_template.entry,
    gameobject_template.displayId,
    gameobject_template.name,
    gameobject_template.flags,
    gameobject_template.type
FROM
    `gameobject`
INNER JOIN
    `gameobject_template` ON `gameobject`.`id` = `gameobject_template`.`entry`
WHERE
  SQRT(
    ('-611.986' - gameobject.position_x) *  ('-611.986' - gameobject.position_x)
    +
    ('-4252.52' - gameobject.position_y) *  ('-4252.52' - gameobject.position_y)
    ) <= 100
ORDER BY `gameobject`.`id` ASC
";

$result = $conn->query($sql);

while ($row = $result->fetch_assoc()) {
    print_r($row);
    echo "https://wotlk.evowow.com/?object={$row['id']}";
    echo "\nhttps://vanillawowdb.com/?object={$row['id']}";
    echo "\nhttps://vanilla-twinhead.twinstar.cz/?object={$row['id']}";
    echo "\nhttps://www.wow-freakz.com/object_finder.php?object={$row['id']}";
    echo "\nhttps://www.wowhead.com/?object={$row['id']}/coco";

    // Search Place
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    /*
    // EVOWOW
    $dom->loadHTMLFile("https://wotlk.evowow.com/?object={$row['id']}");
    $xpath   = new DOMXpath($dom);
    $element = $xpath->query('//*[@id="mapper-zone-generic"]/a')->item(0);
    $local   = $element->nodeValue;
    */

    // WOW-FREAKS
    $dom->loadHTMLFile("https://www.wow-freakz.com/object_finder.php?object={$row['id']}");
    $xpath   = new DOMXpath($dom);
    $element = $xpath->query('//*[@id="a_1"]')->item(0);
    $local   = $element->nodeValue;

    $sql = "UPDATE gameobject SET local = '{$local}' WHERE id = {$row['id']}";

    if ($conn->query($sql) === true) {
        echo "\nRecord updated successfully\n";
    }
    var_dump($local);

    $local = 'Valley of Trials';

    $file   = $local . '.xml';
    if (!is_file($file)) {
        $txt    = "<?xml version=\"1.0\"?>\n\r<zone>\n\r</zone>";
        $myfile = file_put_contents($file, $txt . PHP_EOL, FILE_APPEND | LOCK_EX);
    }
    $xml    = simplexml_load_file($file);
    $child  = $xml->addChild('objeto');
    $child->addAttribute('id', uniqid());
    $child->addAttribute('entry', $row['id']);
    $child->addAttribute('name', $row['name']);
    $child->addAttribute('type', $row['type']);
    $child->addAttribute('model', $row['displayId']);
    $child->addAttribute('flags', $row['flags']);
    $map = $child->addChild('map');
    $map->addAttribute('mapX', $row['position_x']);
    $map->addAttribute('mapY', $row['position_y']);
    $map->addAttribute('mapZ', $row['position_z']);
    $map->addAttribute('mapO', $row['orientation']);
    $xml->asXML($file);
}

$conn->close();
